import pandas as pd
import matplotlib.pyplot as plt

# Load CSV
salaries = pd.read_csv("Salaries.csv")

# Columns
cols = [
    'BasePay',
    'OvertimePay',
    'OtherPay',
    'Benefits',
    'TotalPay',
    'TotalPayBenefits'
]

# Graphs
fig, axes = plt.subplots(2, 3, figsize=(12,5))

for i, col in enumerate(cols):

    row = i // 3
    column = i % 3

    salaries[col].hist(ax=axes[row, column])

    axes[row, column].set_title(col)

    axes[row, column].tick_params(
        axis='x',
        rotation=30
    )

plt.subplots_adjust(hspace=0.8, wspace=0.5)

plt.show()