import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Student data
data = {
    "Students": ["Amit", "Rahul", "Nilesh", "Priya", "Sanket"],
    "Marks": [78, 85, 92, 88, 70]
}

# Convert into DataFrame
df = pd.DataFrame(data)

# Display data
print(df)

# Set graph style
sns.set(style="whitegrid")

# Create bar chart
plt.figure(figsize=(8,5))
sns.barplot(x="Students", y="Marks", data=df)

# Title
plt.title("Student Marks Visualization")

# Labels
plt.xlabel("Students")
plt.ylabel("Marks")

# Show graph
plt.show()
